-- Event to save HUD position
RegisterServerEvent('saveHudPosition')
AddEventHandler('saveHudPosition', function(positionData)
    local src = source
    local identifier = GetPlayerIdentifiers(src)[1]
    -- Save the position data to a database or file
    -- Example: MySQL.Async.execute('UPDATE hud_positions SET position = @position WHERE identifier = @identifier', {['@position'] = json.encode(positionData), ['@identifier'] = identifier})
    print('Saving HUD position for ' .. identifier)
end)

-- Event to load HUD position
RegisterServerEvent('loadHudPosition')
AddEventHandler('loadHudPosition', function()
    local src = source
    local identifier = GetPlayerIdentifiers(src)[1]
    -- Load the position data from a database or file
    -- Example: MySQL.Async.fetchAll('SELECT position FROM hud_positions WHERE identifier = @identifier', {['@identifier'] = identifier}, function(result)
    --     if result[1] then
    --         TriggerClientEvent('loadHudPosition', src, json.decode(result[1].position))
    --     end
    -- end)
    print('Loading HUD position for ' .. identifier)
end)

-- Event to load HUD settings
RegisterServerEvent('loadHudSettings')
AddEventHandler('loadHudSettings', function()
    local src = source
    local identifier = GetPlayerIdentifiers(src)[1]
    -- Load the settings data from a database or file
    -- Example: MySQL.Async.fetchAll('SELECT settings FROM hud_settings WHERE identifier = @identifier', {['@identifier'] = identifier}, function(result)
    --     if result[1] then
    --         TriggerClientEvent('loadHudSettings', src, json.decode(result[1].settings))
    --     end
    -- end)
    print('Loading HUD settings for ' .. identifier)
end)

-- Event to disable HUD settings
RegisterServerEvent('disableHudSettings')
AddEventHandler('disableHudSettings', function()
    local src = source
    TriggerClientEvent('disableHudSettings', src)
end)

-- Event to enable HUD settings
RegisterServerEvent('enableHudSettings')
AddEventHandler('enableHudSettings', function()
    local src = source
    TriggerClientEvent('enableHudSettings', src)
end)

-- Event to close HUD styling and disable cursor mode
RegisterServerEvent('closeHudStyling')
AddEventHandler('closeHudStyling', function()
    local src = source
    TriggerClientEvent('closeHudStyling', src)
    TriggerClientEvent('checkVehicleStatus', src) -- Trigger vehicle status check
end)

-- Event to save HUD settings
RegisterServerEvent('saveHudSettings')
AddEventHandler('saveHudSettings', function(settingsData)
    local src = source
    local identifier = GetPlayerIdentifiers(src)[1]
    -- Save the settings data to a database or file
    -- Example: MySQL.Async.execute('UPDATE hud_settings SET settings = @settings WHERE identifier = @identifier', {['@settings'] = json.encode(settingsData), ['@identifier'] = identifier})
    print('Saving HUD settings for ' .. identifier)
    TriggerClientEvent('checkVehicleStatus', src) -- Trigger vehicle status check
end)