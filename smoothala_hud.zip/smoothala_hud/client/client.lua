local isHudSettingsEnabled = false

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)
        local sleep = 1000

        if vehicle ~= 0 and not isHudSettingsEnabled then
            sleep = 150
            local speed = math.ceil(GetEntitySpeed(vehicle) * 3.6) -- Convert m/s to km/h
            local fuel = GetVehicleFuelLevel(vehicle)
            local gear = GetVehicleCurrentGear(vehicle)
            local maxGear = GetVehicleHighGear(vehicle)

            SendNUIMessage({
                action = 'showSpeed',
                speed = speed,
                fuel = fuel,
                gear = gear,
                maxGear = maxGear
            })
        else
            SendNUIMessage({
                action = 'hideSpeed'
            })
        end

        SendNUIMessage({
            type = 'sethp',
            hp = GetEntityHealth(ped) - 100,
            armour = GetPedArmour(ped)
        })

        Wait(sleep)
    end
end)

RegisterCommand('alahud', function()
    isHudSettingsEnabled = not isHudSettingsEnabled
    SendNUIMessage({
        action = 'openHudStyling',
        enable = isHudSettingsEnabled
    })
    SetNuiFocus(isHudSettingsEnabled, isHudSettingsEnabled) -- Enable cursor mode

    -- Hide car HUD if opening the styling menu
    if isHudSettingsEnabled then
        SendNUIMessage({
            action = 'hideSpeed'
        })
    else
        -- Check vehicle status and show car HUD if in a vehicle
        TriggerEvent('checkVehicleStatus')
    end
end)

RegisterNUICallback('closeHudStyling', function(data, cb)
    isHudSettingsEnabled = false
    SetNuiFocus(false, false) -- Disable cursor mode
    SendNUIMessage({
        action = 'hideHudStyling'
    })
    TriggerEvent('checkVehicleStatus') -- Trigger vehicle status check
    cb('ok')
end)

RegisterNUICallback('saveHudSettings', function(data, cb)
    isHudSettingsEnabled = false
    SetNuiFocus(false, false) -- Disable cursor mode
    SendNUIMessage({
        action = 'hideHudStyling'
    })
    TriggerEvent('checkVehicleStatus') -- Trigger vehicle status check
    cb('ok')
end)

RegisterNetEvent('loadHudSettings')
AddEventHandler('loadHudSettings', function(settings)
    SendNUIMessage({
        action = 'loadHudSettings',
        hpColor = settings.hpColor,
        armourColor = settings.armourColor,
        speedColor = settings.speedColor,
        fuelColor = settings.fuelColor
    })
end)

RegisterNetEvent('checkVehicleStatus')
AddEventHandler('checkVehicleStatus', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 or isHudSettingsEnabled then
        SendNUIMessage({
            action = 'hideSpeed'
        })
    else
        SendNUIMessage({
            action = 'showSpeed'
        })
    end
end)