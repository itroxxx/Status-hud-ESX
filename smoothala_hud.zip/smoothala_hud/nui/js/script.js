$(document).ready(function() {
    let isHudSettingsEnabled = false;
    let isMoveEnabled = false;
    let previousGear = 0;

    function checkVehicleStatus() {
        $.post('https://smoothala_hud/checkVehicleStatus', {}, function(response) {
            if (!response.inVehicle || isHudSettingsEnabled) {
                $('.carhud').hide();
                $('#lap_container').hide();
                $('#speed').hide();
                $('#fuel_container').hide();
            } else {
                $('.carhud').show();
                $('#lap_container').show();
                $('#speed').show();
                $('#fuel_container').show();
            }
        });
    }

    window.addEventListener("message", function(event) {
        if (event.data.type === 'sethp') {
            $("#hp").css('width', event.data.hp + '%');
            $("#armour").css('width', event.data.armour + '%');
        }
        
        if (event.data.action === 'showSpeed') {
            $("#speed").text(event.data.speed + ' km/h');

            // Update fuel level
            let fuel = event.data.fuel;
            $('#fuel').css('width', fuel + '%');

            // Change fuel color based on level
            if (fuel > 50) {
                $('#fuel').css('background-color', 'green');
            } else if (fuel > 25) {
                $('#fuel').css('background-color', 'yellow');
            } else {
                $('#fuel').css('background-color', 'red');
            }

            // Update lap meter based on speed within the current gear
            let currentGear = event.data.gear;
            let maxGear = event.data.maxGear;
            let lapWidth;

            if (currentGear !== previousGear) {
                lapWidth = 0;
            } else {
                lapWidth = (event.data.speed / (maxGear * 20)) * 100; // Assuming max speed per gear is 20 km/h
            }

            previousGear = currentGear;
            $('#lap').css('width', lapWidth + '%');

            if (!isHudSettingsEnabled) {
                $('.carhud').show();
                $('#lap_container').show();
                $('#speed').show();
                $('#fuel_container').show();
            }
        } else if (event.data.action === 'hideSpeed') {
            $('.carhud').hide();
            $('#lap_container').hide();
            $('#speed').hide();
            $('#fuel_container').hide();
        } else if (event.data.action === 'openHudStyling') {
            isHudSettingsEnabled = event.data.enable;
            if (isHudSettingsEnabled) {
                $('#hud-styling').show();
                $('body').css('cursor', 'default'); // Show cursor

                // Hide car HUD immediately when opening the styling menu
                $('.carhud').hide();
                $('#lap_container').hide();
                $('#speed').hide();
                $('#fuel_container').hide();
            } else {
                $('#hud-styling').hide();
                $('body').css('cursor', 'none'); // Hide cursor

                // Check vehicle status and show car HUD if in a vehicle
                checkVehicleStatus();
            }
        } else if (event.data.action === 'loadHudSettings') {
            // Load saved settings
            $('#hp').css('background-color', event.data.hpColor);
            $('#armour').css('background-color', event.data.armourColor);
            $('#speed').css('color', event.data.speedColor);
            $('#fuel').css('background-color', event.data.fuelColor);
        } else if (event.data.action === 'hideHudStyling') {
            $('#hud-styling').hide();
            $('body').css('cursor', 'none'); // Hide cursor
        }
    });

    $('#closeHudStyling').click(function() {
        $('#hud-styling').hide();
        $('body').css('cursor', 'none'); // Hide cursor
        $.post('nui://smoothala_hud/disableHudSettings');
        $.post('https://smoothala_hud/closeMenu');
        $.post('https://smoothala_hud/closeHudStyling'); // Notify server to disable cursor mode

        // Directly hide HUD elements if not in a vehicle
        checkVehicleStatus();
    });

    $('#saveSettings').click(function() {
        let hpColor = $('#hpColor').val();
        let armourColor = $('#armourColor').val();
        let speedColor = $('#speedColor').val();
        let fuelColor = $('#fuelColor').val();

        $('#hp').css('background-color', hpColor);
        $('#armour').css('background-color', armourColor);
        $('#speed').css('color', speedColor);
        $('#fuel').css('background-color', fuelColor);

        // Save settings to the server
        $.post('https://smoothala_hud/saveHudSettings', JSON.stringify({
            hpColor: hpColor,
            armourColor: armourColor,
            speedColor: speedColor,
            fuelColor: fuelColor
        }));

        $('#hud-styling').hide();
        $('body').css('cursor', 'none'); // Hide cursor
        $.post('nui://smoothala_hud/disableHudSettings');
        $.post('https://smoothala_hud/closeMenu');
        $.post('https://smoothala_hud/closeHudStyling'); // Notify server to disable cursor mode

        // Directly hide HUD elements if not in a vehicle
        checkVehicleStatus();
    });

    $('#cancelSettings').click(function() {
        $('#hud-styling').hide();
        $('body').css('cursor', 'none'); // Hide cursor
        $.post('nui://smoothala_hud/disableHudSettings');
        $.post('https://smoothala_hud/closeMenu');
        $.post('https://smoothala_hud/closeHudStyling'); // Notify server to disable cursor mode

        // Directly hide HUD elements if not in a vehicle
        checkVehicleStatus();
    });

    $('#moveHud').click(function() {
        isMoveEnabled = !isMoveEnabled;
        if (isMoveEnabled) {
            enableDragging();
        } else {
            disableDragging();
        }
    });

    function enableDragging() {
        $(".hp_container, .carhud, .lap_container, .fuel_container, #speed").draggable({
            stop: function(event, ui) {
                // Save the new position
                let id = $(this).attr('id');
                let position = ui.position;
                $.post('nui://smoothala_hud/saveHudPosition', JSON.stringify({
                    id: id,
                    position: position
                }));
            }
        });
    }

    function disableDragging() {
        $(".hp_container, .carhud, .lap_container, .fuel_container, #speed").draggable("destroy");
    }

    $(document).keydown(function(event) {
        if (isHudSettingsEnabled && event.which === 27) { // ESC key
            isHudSettingsEnabled = false;
            $('body').css('cursor', 'none'); // Hide cursor
            $.post('nui://smoothala_hud/disableHudSettings');
            SendNUIMessage({
                action: 'enableHudSettings',
                enable: false
            });
            $.post('https://smoothala_hud/closeHudStyling'); // Notify server to disable cursor mode

            // Directly hide HUD elements if not in a vehicle
            checkVehicleStatus();
        }
    });

    // Periodically check vehicle status to update HUD visibility
    setInterval(checkVehicleStatus, 1000); // Check every second
});