fx_version 'cerulean'
game 'gta5'

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

files {
    'nui/ui.html',
    'nui/js/script.js',
    'nui/fonts/*.ttf',
    'nui/style.css'
}

ui_page 'nui/ui.html'